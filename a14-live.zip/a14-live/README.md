# A14 Live · Suffolk

Live incidents, accidents, lane closures and road closures on the A14 from Newmarket (J37) to Felixstowe (J62), including the Orwell Bridge. Tap any item in the list to highlight it on the map.

## What's in the folder

- `index.html` – the app (list, filters, Orwell Bridge status, interactive map)
- `netlify/functions/a14.mjs` – a small server function that calls National Highways with your key, keeps only A14 Suffolk events and caches the result for 90 seconds
- `netlify.toml` – tells Netlify where things are

## Set it up (about 10 minutes)

1. **Get a free API key.** Sign up at https://developer.data.nationalhighways.co.uk, go to Subscriptions, subscribe to **Road and Lane Closures**, then copy your key from your Profile page.
2. **Deploy to Netlify.** Drag this whole folder onto https://app.netlify.com/drop, or connect it from GitHub.
3. **Add the key.** In Netlify: Site configuration → Environment variables → add `NH_API_KEY` with your key.
4. **Redeploy** (Deploys → Trigger deploy). Open the site and the list fills with live data.

To preview the design without a key, open the site with `#sample` on the end of the address. Sample data is clearly marked and is never mixed with live data.

## Notes

- The National Highways API allows 10 calls a minute. The function's shared 90-second cache keeps you well inside that however many people use the page.
- If items show up in the wrong place or with vague titles, open `/api/a14?debug=1` on your site. It includes a slice of the raw feed, which makes it quick to tune the parser.
- Junction positions are approximate. Local council roadworks (for example on slip-road roundabouts run by Suffolk County Council) are not in the National Highways feed.

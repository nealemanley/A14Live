// A14 Live — server-side proxy for the National Highways "Road and Lane Closures" API (v2, DATEX II JSON).
// Keeps your API key secret, merges planned + unplanned events, filters to the A14 between
// Newmarket (J37) and Felixstowe (J62), and returns a small, clean JSON list for the web page.
//
// Set the environment variable NH_API_KEY in Netlify (Site configuration → Environment variables).
// Free key: https://developer.data.nationalhighways.co.uk  (subscribe to "Road and Lane Closures")

const API = "https://api.data.nationalhighways.co.uk/roads/v2.0/closures";
const MAX_PAGES = 4;

// Corridor box around the A14 from Newmarket to Felixstowe (a little padding either side).
const BOX = { minLat: 51.93, maxLat: 52.32, minLon: 0.33, maxLon: 1.37 };

// Approximate junction positions, west → east. Used to label where an event is.
export const JUNCTIONS = [
  ["37", 52.2738, 0.3923, "Newmarket / Exning (A142)"],
  ["38", 52.2808, 0.4405, "A11 Thetford, Norwich"],
  ["39", 52.2656, 0.4985, "Kentford"],
  ["40", 52.2611, 0.5642, "Higham"],
  ["41", 52.2562, 0.6432, "Risby"],
  ["42", 52.2536, 0.6893, "Bury St Edmunds West"],
  ["43", 52.2583, 0.7128, "Bury St Edmunds Central (A134)"],
  ["44", 52.2421, 0.7423, "Bury St Edmunds East"],
  ["45", 52.2398, 0.7722, "Rougham / Great Barton"],
  ["46", 52.2449, 0.8371, "Thurston / Beyton"],
  ["47", 52.2369, 0.8921, "Woolpit (A1088)"],
  ["47A", 52.2212, 0.9441, "Haughley / Wetherden"],
  ["49", 52.2119, 0.9781, "Tot Hill (A1308)"],
  ["50", 52.1951, 1.0052, "Stowmarket (A1120)"],
  ["51", 52.1532, 1.0631, "Beacon Hill (A140)"],
  ["52", 52.1081, 1.1041, "Claydon"],
  ["53", 52.0801, 1.1152, "Whitehouse (A1156)"],
  ["54", 52.0571, 1.1001, "Sproughton"],
  ["55", 52.0312, 1.1052, "Copdock (A12)"],
  ["56", 52.0281, 1.1401, "Wherstead (A137)"],
  ["57", 52.0392, 1.2152, "Nacton (A1189)"],
  ["58", 52.0401, 1.2551, "Seven Hills (A12)"],
  ["59", 51.9901, 1.3051, "Trimley"],
  ["60", 51.9702, 1.3252, "Dock Spur roundabout (A154)"],
  ["61", 51.9621, 1.3272, "Dock Gate 2"],
  ["62", 51.9521, 1.3381, "Dock Gate 1"],
];
const ORWELL = { lat: 52.0305, lon: 1.1735, radiusKm: 1.6 };

export default async (req) => {
  const url = new URL(req.url);
  const debug = url.searchParams.get("debug") === "1";
  const key = (globalThis.Netlify?.env?.get?.("NH_API_KEY")) || process.env.NH_API_KEY;
  if (!key) {
    return json({ ok: false, error: "missing_key",
      message: "The server has no National Highways API key. Add NH_API_KEY in Netlify environment variables and redeploy." }, 500, 0);
  }

  const now = new Date();
  const iso = (d) => d.toISOString().replace(/\.\d{3}Z$/, "Z");
  const hours = (h) => new Date(now.getTime() + h * 3600e3);

  const queries = [
    { closureType: "unplanned", startDateTime: iso(hours(-24)), endDateTime: iso(hours(1)) },
    { closureType: "planned", startDateTime: iso(hours(-1)), endDateTime: iso(hours(24)) },
  ];

  const raw = [];
  const errors = [];
  for (const q of queries) {
    try {
      const pages = await fetchAll(q, key);
      raw.push(...pages.map((p) => ({ closureType: q.closureType, body: p })));
    } catch (e) {
      errors.push(`${q.closureType}: ${e.message}`);
    }
  }
  if (!raw.length && errors.length) {
    return json({ ok: false, error: "upstream", message: errors.join(" · ") }, 502, 30);
  }

  const events = [];
  const seen = new Set();
  for (const { closureType, body } of raw) {
    for (const ev of extractEvents(body, closureType)) {
      if (seen.has(ev.id)) continue;
      seen.add(ev.id);
      if (isOnCorridor(ev)) events.push(decorate(ev, now));
    }
  }
  events.sort((a, b) => rank(a) - rank(b) || (b.updated || "").localeCompare(a.updated || ""));

  const out = { ok: true, fetchedAt: now.toISOString(), source: "National Highways", count: events.length, events, warnings: errors };
  if (debug) out.sample = JSON.stringify(raw[0]?.body ?? null).slice(0, 6000);
  return json(out, 200, 90);
};

// ---------- upstream ----------
async function fetchAll(params, key) {
  const pages = [];
  let cursor = null;
  for (let i = 0; i < MAX_PAGES; i++) {
    const u = new URL(API);
    for (const [k, v] of Object.entries(params)) u.searchParams.set(k, v);
    if (cursor) u.searchParams.set("pageCursor", cursor);
    const r = await fetch(u, {
      headers: {
        "Ocp-Apim-Subscription-Key": key,
        "X-Response-MediaType": "application/json",
        "X-Data-Format": "DATEXII",
        "Cache-Control": "no-cache",
      },
      redirect: "manual",
      signal: AbortSignal.timeout(12000),
    });
    if (r.status === 204) break;
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    pages.push(await r.json());
    cursor = r.headers.get("x-next");
    if (!cursor) break;
  }
  return pages;
}

// ---------- DATEX II walking (tolerant of schema differences) ----------
function extractEvents(body, closureType) {
  const situations = [];
  walk(body, (node, keyName) => {
    if (Array.isArray(node) && /^situation$/i.test(keyName)) situations.push(...node);
  });
  // Fall back to treating every situationRecord array as its own group.
  if (!situations.length) {
    walk(body, (node, keyName) => {
      if (Array.isArray(node) && /situationRecord$/i.test(keyName)) situations.push({ situationRecord: node });
    });
  }
  return situations.map((s, i) => summarise(s, closureType, i)).filter(Boolean);
}

function summarise(sit, closureType, i) {
  const records = [];
  walk(sit, (node, keyName) => {
    if (Array.isArray(node) && /situationRecord$/i.test(keyName)) records.push(...node.filter(isObj));
  });
  if (!records.length) records.push(sit);

  const types = new Set(), texts = [], roads = new Set(), coords = [], dirs = new Set(), mgmt = new Set();
  let start = null, end = null, updated = null, severity = null, lanes = null;

  for (const rec of records) {
    const t = rec["xsi:type"] || rec["@xsi:type"] || rec.type || rec["@type"] || rec.situationRecordType;
    if (typeof t === "string") types.add(t.replace(/^.*:/, ""));
    walk(rec, (node, k, parent) => {
      if (typeof node === "string") {
        const lk = k.toLowerCase();
        if ((lk === "value" || lk === "comment" || lk.endsWith("comment")) && node.length > 3 && !/^\d/.test(node)) texts.push(node.trim());
        if (lk.includes("roadname") || lk.includes("roadnumber") || lk === "roadidentifier") roads.add(node.trim());
        if (lk.includes("direction") || lk === "carriageway") dirs.add(node);
        if (lk.endsWith("managementtype") || lk.endsWith("accidenttype") || lk.endsWith("obstructiontype") ||
            lk.endsWith("maintenancetype") || lk.endsWith("worktype") || lk.endsWith("abnormaltraffictype") ||
            lk === "laneusage" || lk.endsWith("closures") || lk === "closuretype") mgmt.add(node);
        if (lk === "overallstarttime" && !start) start = node;
        if (lk === "overallendtime" && !end) end = node;
        if ((lk === "situationrecordversiontime" || lk === "versiontime" || lk === "situationversiontime") && (!updated || node > updated)) updated = node;
        if (lk === "severity" || lk === "overallseverity") severity = node;
        if (lk === "poslist") {
          const n = node.trim().split(/[\s,]+/).map(Number).filter((x) => !isNaN(x));
          for (let j = 0; j + 1 < n.length; j += 2) addCoord(coords, n[j], n[j + 1]);
        }
      }
      if (typeof node === "number") {
        const lk = k.toLowerCase();
        if (lk === "numberoflanesrestricted" || lk === "numberoflanes") lanes = node;
      }
      if (isObj(node) && node.latitude != null && node.longitude != null) addCoord(coords, +node.latitude, +node.longitude);
      if (Array.isArray(node) && /^(lane|laneusage|lanes)$/i.test(k)) lanes = lanes ?? node.length;
      return parent;
    });
  }

  // A14 also often appears only in free text.
  for (const s of texts) for (const m of s.matchAll(/\bA14\b/g)) roads.add(m[0]);
  const id = String(sit.id || sit["@id"] || sit.situationId || records[0]?.id || `${closureType}-${i}-${hash(texts.join("|"))}`);

  return {
    id, closureType,
    types: [...types], mgmt: [...mgmt], roads: [...roads], dirs: [...dirs],
    text: dedupe(texts).slice(0, 4), coords: coords.slice(0, 200),
    start, end, updated: updated || start, severity, lanes,
  };
}

function isOnCorridor(ev) {
  const onA14 = ev.roads.some((r) => /\bA14\b/i.test(r)) || ev.text.some((t) => /\bA14\b/.test(t));
  if (!onA14) return false;
  if (ev.coords.length) return ev.coords.some(([la, lo]) => la >= BOX.minLat && la <= BOX.maxLat && lo >= BOX.minLon && lo <= BOX.maxLon);
  // No coordinates: keep it only if the text names a junction or place on this stretch.
  return ev.text.some((t) => /\bJ(unction)?\s?(3[7-9]|4\d|5\d|6[0-2])\b|Newmarket|Bury|Stowmarket|Ipswich|Orwell|Felixstowe|Copdock|Nacton|Trimley|Claydon|Woolpit|Haughley|Kentford/i.test(t));
}

function decorate(ev, now) {
  const all = (ev.types.join(" ") + " " + ev.mgmt.join(" ") + " " + ev.text.join(" "));
  let category = "incident";
  if (/accident|collision|crash|overturned|vehicle fire/i.test(all)) category = "accident";
  else if (/roadClosed|carriagewayClosures|road closed|carriageway closed|closure of the carriageway|\bclosed\b/i.test(all) && !/lane closure|laneClosures|lane[s]? closed/i.test(all)) category = "closure";
  else if (/laneClosures|lane closure|lanes? closed|narrowLanes|singleAlternateLineTraffic|contraflow/i.test(all)) category = "lanes";
  else if (ev.closureType === "planned" || /maintenance|roadworks|construction|resurfacing|works/i.test(all)) category = "roadworks";
  else if (/obstruction|debris|animal|broken ?down|breakdown|flood|wind|ice|fog|spillage/i.test(all)) category = "incident";

  const pts = ev.coords.length ? ev.coords : textJunctionPoints(ev.text);
  const near = pts.map(([la, lo]) => nearestJunctionIndex(la, lo));
  const lo = near.length ? Math.min(...near) : null, hi = near.length ? Math.max(...near) : null;
  const orwell = /orwell/i.test(ev.text.join(" ")) || pts.some(([la, lon]) => km(la, lon, ORWELL.lat, ORWELL.lon) <= ORWELL.radiusKm);

  let direction = null;
  const d = (ev.dirs.join(" ") + " " + ev.text.join(" "));
  if (/east ?bound|\bE\/B\b|eastbound/i.test(d)) direction = "Eastbound";
  if (/west ?bound|\bW\/B\b|westbound/i.test(d)) direction = direction ? "Both directions" : "Westbound";
  if (/both directions|bothWays|allDirections/i.test(d)) direction = "Both directions";

  const live = !ev.start || new Date(ev.start) <= now;
  return {
    id: ev.id, category, closureType: ev.closureType, live,
    title: titleFor(category, ev),
    detail: ev.text[0] || null,
    extra: ev.text.slice(1, 3),
    direction, lanes: ev.lanes, severity: ev.severity,
    fromJ: lo != null ? JUNCTIONS[lo][0] : null, toJ: hi != null ? JUNCTIONS[hi][0] : null,
    orwell, start: ev.start, end: ev.end, updated: ev.updated,
    points: thin(pts, 60),
  };
}

function titleFor(cat, ev) {
  const lanes = ev.lanes ? `${ev.lanes} lane${ev.lanes > 1 ? "s" : ""} closed` : "Lane closure";
  return { accident: "Accident", closure: "Road closed", lanes, roadworks: "Roadworks", incident: incidentName(ev) }[cat];
}
function incidentName(ev) {
  const t = (ev.types.join(" ") + " " + ev.mgmt.join(" ") + " " + ev.text.join(" "));
  if (/broken ?down|breakdown|vehicleObstruction|stationary vehicle/i.test(t)) return "Broken-down vehicle";
  if (/debris|object/i.test(t)) return "Debris in road";
  if (/animal/i.test(t)) return "Animal in road";
  if (/wind/i.test(t)) return "High winds";
  if (/flood/i.test(t)) return "Flooding";
  if (/spillage|spill/i.test(t)) return "Spillage";
  return "Incident";
}
function rank(e) { return { closure: 0, accident: 1, incident: 2, lanes: 3, roadworks: 4 }[e.category] + (e.live ? 0 : 10); }

function textJunctionPoints(texts) {
  const pts = [];
  for (const t of texts) for (const m of t.matchAll(/\bJ(?:unction)?\s?(\d{2}A?)\b/gi)) {
    const j = JUNCTIONS.find((x) => x[0] === m[1].toUpperCase());
    if (j) pts.push([j[1], j[2]]);
  }
  return pts;
}
function nearestJunctionIndex(la, lo) {
  let best = 0, bd = Infinity;
  JUNCTIONS.forEach((j, i) => { const d = km(la, lo, j[1], j[2]); if (d < bd) { bd = d; best = i; } });
  return best;
}

// ---------- helpers ----------
function walk(node, fn, key = "", parent = null) {
  fn(node, key, parent);
  if (Array.isArray(node)) node.forEach((c) => walk(c, fn, key, node));
  else if (isObj(node)) for (const [k, v] of Object.entries(node)) walk(v, fn, k, node);
}
function isObj(x) { return x && typeof x === "object" && !Array.isArray(x); }
function addCoord(arr, a, b) {
  // DATEX posList is "lat lon"; guard against lon/lat order by checking UK ranges.
  if (a > 49 && a < 61 && b > -9 && b < 3) arr.push([a, b]);
  else if (b > 49 && b < 61 && a > -9 && a < 3) arr.push([b, a]);
}
function km(a, b, c, d) {
  const R = 6371, r = Math.PI / 180, x = (d - b) * r * Math.cos(((a + c) / 2) * r), y = (c - a) * r;
  return Math.sqrt(x * x + y * y) * R;
}
function dedupe(a) { return [...new Set(a.map((s) => s.replace(/\s+/g, " ")))]; }
function thin(pts, n) { if (pts.length <= n) return pts; const s = pts.length / n; return Array.from({ length: n }, (_, i) => pts[Math.floor(i * s)]); }
function hash(s) { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) | 0; return (h >>> 0).toString(36); }

function json(obj, status, maxAge) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      // Shared CDN cache keeps us well inside the API's 10 calls/minute limit however many people use the page.
      "Netlify-CDN-Cache-Control": maxAge ? `public, s-maxage=${maxAge}, stale-while-revalidate=60` : "no-store",
      "Cache-Control": "no-cache",
    },
  });
}

export const config = { path: "/api/a14" };
